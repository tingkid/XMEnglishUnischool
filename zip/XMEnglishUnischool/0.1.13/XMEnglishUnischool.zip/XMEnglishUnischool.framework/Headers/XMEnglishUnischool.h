//
//  XMEnglishUnischool.h
//  AFNetworking
//
//  Created by zll on 2022/6/2.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
NS_ASSUME_NONNULL_BEGIN

///  初始化时的配置信息
@interface XMConfigOptions: NSObject

/// 输出日志
@property(nonatomic, assign, getter=isEnableLog) BOOL enableLog;

/// 调试
@property(nonatomic, assign, getter=isDebug) BOOL debug;

///[challenge previousFailureCount] != 0，在调试模式下有效
@property(nonatomic, assign) NSURLSessionAuthChallengeDisposition previousFailureDisposition;
/// ![challenge.protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust]，在调试模式下有效
@property(nonatomic, assign) NSURLSessionAuthChallengeDisposition serverTrustDisposition; 

@end

typedef NS_ENUM(NSUInteger, XMOpenWebType) {
    XMOpenWebType_Defalut, /// 默认的 ，喜马内部的
    XMOpenWebType_Angel, /// 纯净的
    XMOpenWebType_Third, ///三方提供
};


/// 委托，需要调用一些方法，比如分享、支持方向的改动等
@protocol XMEnglishUnischoolDelegate <NSObject>

/// 支持横屏
- (void)supportedLandscapeInterfaceOrientations;

/// 登录成功
- (void)userLoginSuccessWithUid:(NSString *)uid;
/// 退出登录
///  在清除登录信息或登录信息失效时调用
- (void)userLogoutWithUid:(NSString *)uid;

@optional
/// 打开隐私协议页的方式
- (XMOpenWebType)openPrivacyWebType;
/// 在openPrivacyWebType的返回值为XMOpenWebType_Third时会调用
- (UIViewController *)openThirdPrivacyWebWithURLString:(NSString *)URLString;

@end

/**
 */
@interface XMLessonInfo : NSObject

/// 指定训练营id列表
@property (nonatomic, strong) NSArray<NSString *> *campIdList;
/// 书册id列表
@property (nonatomic, strong) NSArray<NSString *> *levelIdList;
/// 0-体验课 1-正式课
@property(nonatomic, assign) NSInteger lessonType;

///调试模式使用
@property (nonatomic, nullable, strong) NSString *debugParames;

@end

///  打开学习页时的参数
@interface XMPageParameter: NSObject

/// 手机号
@property (nonatomic, strong) NSString *phone;
/// 用来push或者present新的控制器
@property (nonatomic, weak)  UIViewController *currentVC;
/// 委托
@property (nonatomic, weak) id<XMEnglishUnischoolDelegate> delegate;

///课程信息
@property (nonatomic, strong) XMLessonInfo *lessonInfo;

@end


@interface XMEnglishUnischool : NSObject

/// 初始化
/// 声明周期调用一次即可
/// @param options 配置信息
+ (void)initWithConfigOptions:(XMConfigOptions *)options;

/// 打开学习页
/// 没有关联，会自动调用登录页关联
/// @param parameter 打开学习页时的参数，不可为空，内部的每个属性也不可为空
+ (void)openLessonPageWithParameter:(XMPageParameter *)parameter;

/// 某个手机号是否登录
/// @param phone 手机号，要符合标准的
+ (BOOL)isLoginWithPhone:(NSString *)phone;

/// 清除喜马的登录信息
/// 出登录或者切换账号是需要清除账号关联信息
+ (void)clearXmAccount;

/// 获取喜马已登录的用户uid，
/// 未登录时返回空
+ (nullable NSString *)getXmLoginedUserId;

/// 版本号
+ (NSString *)sdkVersion;

@end

NS_ASSUME_NONNULL_END
