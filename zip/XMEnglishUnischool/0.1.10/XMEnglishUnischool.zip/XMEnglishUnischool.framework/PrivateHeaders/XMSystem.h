//
//  XMSystem.h
//  Component
//
//  Created by tdwang on 2018/4/20.
//  Copyright © 2018年 tdwang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#define kCookieDeviceKey        [XMSystem cookieDeviceKey]
#define kCookieTokenKey         [XMSystem cookieTokenKey]
#define KVUidToken(u, t) [NSString stringWithFormat:@"%lld&%@",  u, t]

extern NSString * const kBundleName;
extern NSString * const kBundleIndentifier;
extern NSString * const kTestBundleIndentifier;

@interface XMSystem : NSObject

+ (BOOL)iOS9OrLater;
+ (BOOL)iOS10OrLater;
+ (BOOL)iOS12OrLater;
+ (BOOL)iOS13OrLater;

+ (CGFloat)statusBarHeight;
+ (double)safeAreaBottomInset;
+ (double)safeAreaTopInset;
+ (CGFloat)navigationbarHeight;
+ (CGFloat)navigationHeight;
+ (NSString *)systemName;
+ (NSString *)systemVersion;
+ (NSInteger)systemMainVersion;


+ (NSString *)getChannelId;
+ (NSString *)uniqueDeviceIdentifier;
+ (NSString *)bundleIdentifier;
+ (NSString *)bundleReleaseVersion;  // release version
+ (NSString *)bundleBuildVersion;

+ (NSString *)cookieDeviceKey;
+ (NSString *)cookieTokenKey;
+ (NSString *)userAgent;

+ (NSString*)signRequestVerifyToken:(NSDictionary*)param;
+ (NSString*)signTrackBuyRequestVerifyToken:(NSDictionary*)param;

+ (NSString *)uniKeyFilePath;
+ (NSDictionary *)uploadBodyWithDeviceToken:(NSString *)deviceToken isOpenPush:(BOOL)isOpenPush;

@end

@interface XMSystem (DDDeviceInfo)

/**app名称*/
+ (NSString *)appName;
/**设备型号名*/
+ (NSString *)deviceName;

/**手机当前所处网络的IP*/
+ (NSString *)deviceIP;

/**是模拟器还是手机，模拟器：@“0”，手机：“1”*/
+ (NSString *)deviceReal;
/**手机的uuid*/
+ (NSString *)uuid;
///**手机的idfa*/
//+ (NSString *)idfa;

@end
