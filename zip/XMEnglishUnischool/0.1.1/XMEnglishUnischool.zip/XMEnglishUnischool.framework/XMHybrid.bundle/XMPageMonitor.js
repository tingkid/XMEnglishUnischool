var XMPageMonitor = (function () {
    function XMPageMonitor(win) {
        this.win = win;
    }
    
    XMPageMonitor.prototype.putExtraInfo = function (info) {
        var message = {
            method: "putExtraInfo",
            data: info
        };
        
        this.win.webkit.messageHandlers.XMPageMonitor.postMessage(message);
    };

    return XMPageMonitor;
}());

var xmPageMonitor = new XMPageMonitor(window);
